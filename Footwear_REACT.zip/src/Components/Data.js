import item1 from "../images/item-1.jpg"
import item2 from "../images/item-2.jpg"
import item3 from "../images/item-3.jpg"
import item4 from "../images/item-4.jpg"
import item5 from "../images/item-5.jpg"
import item6 from "../images/item-6.jpg"
import item7 from "../images/item-7.jpg"
import item8 from "../images/item-8.jpg"
import item9 from "../images/item-9.jpg"
import item10 from "../images/item-10.jpg"
import item11 from "../images/item-11.jpg"
import item12 from "../images/item-12.jpg"

const Data = {
    ProductData:[
        {
            id: 1,
            img: item1,
            title: "Men's Taja Commissioner",
            text: "",
            price: 130
        },
        {
            id: 1,
            img: item2,
            title: "Men's Taja Commissioner",
            text: "",
            price: 130
        },
        {
            id: 1,
            img: item3,
            title: "Men's Taja Commissioner",
            text: "",
            price: 130
        },
        {
            id: 1,
            img: item4,
            title: "Men's Taja Commissioner",
            text: "",
            price: 130
        },
        {
            id: 1,
            img: item5,
            title: "Men's Taja Commissioner",
            text: "",
            price: 130
        },
        {
            id: 1,
            img: item6,
            title: "Men's Taja Commissioner",
            text: "",
            price: 130
        },
        {
            id: 1,
            img: item7,
            title: "Men's Taja Commissioner",
            text: "",
            price: 130
        },
        {
            id: 1,
            img: item8,
            title: "Men's Taja Commissioner",
            text: "",
            price: 130
        },
        {
            id: 1,
            img: item9,
            title: "Men's Taja Commissioner",
            text: "",
            price: 130
        },
        {
            id: 1,
            img: item10,
            title: "Men's Taja Commissioner",
            text: "",
            price: 130
        },
        {
            id: 1,
            img: item11,
            title: "Men's Taja Commissioner",
            text: "",
            price: 130
        },
        {
            id: 1,
            img: item12,
            title: "Men's Taja Commissioner",
            text: "",
            price: 130
        }
    ]
};

export default Data;