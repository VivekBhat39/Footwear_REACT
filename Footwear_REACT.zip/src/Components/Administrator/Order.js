import React from 'react'

const Order = () => {
    return (
        <div>
            <div className="breadcrumbs">
                <div className="container">
                    <div className="row">
                        <div className="col">
                            <p className="bread"><span><a href="">Admin</a></span> / <span>Order</span></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Order;