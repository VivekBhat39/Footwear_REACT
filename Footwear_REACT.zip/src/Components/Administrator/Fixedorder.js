import React from 'react'

const fixedorder = () => {
    return (
        <div>
            <div className="breadcrumbs">
                <div className="container">
                    <div className="row">
                        <div className="col">
                            <p className="bread"><span><a href="">Admin</a></span> / <span>fixedorder</span></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default fixedorder;